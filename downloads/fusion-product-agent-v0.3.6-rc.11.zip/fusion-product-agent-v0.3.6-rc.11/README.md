# 融合产品锤 0.3.6-rc.11

本地 rc.11 候选包含001—006六项修复及已批准的设计流程修订；设计目录按主成果、工作环节与专项子任务组织，方法和资源保留。产品界面与网站已细化各环节的方法、资源和自审，其他主流程及专项细则尚未全部补齐。本候选与已发布 0.3.4 安装包分开，具体范围与重新导入注意事项见 [来源说明](SOURCE-MAP.md)。

**Demo统一定义**：[正式产品的本地前端交付](skills/fusion-product-agent/references/formal-design-delivery.md)，约定范围内的界面、交互、文案与目标生产规格一致；本地数据/受控返回只替代服务接入，不能以Demo名义降低体验标准。

已保留第002项：[正式设计交付](skills/fusion-product-agent/references/formal-design-delivery.md)区分探索、主稿与按稿还原，正式页面面向实际用户；保留第001项文案审查可见性。

2026-11-07本地rc.11开发候选，承接GitHub main的rc.7及个人分支rc.8/rc.9；本轮归回开发分支，尚未推送、发布或安装，未并入独立的v0.3.5-rc.1一致性检查候选。产品领域研究、需求与规则、复杂状态、业务验收和交接沿用融合锤子；设计判断采用同事分支的专家模块；原有Figma执行流程独立随包提供，不再运行旧设计判断方法。按本轮归回前保留的分发记录，GitHub主分支及候选ZIP提供rc.7，维护者本机安装试用rc.7；最新正式Release为v0.3.4。rc.11与远端和已安装版本分开。

## 产品主线与设计环节

这是产品锤，设计是其中的专业环节。只有产品名称或粗略想法时，先按[产品启动条件](skills/fusion-product-agent/references/product-start.md)给出候选与推荐，校准用途、使用者/场景和核心范围，再进入方案与制作。普通可逆细节可自主推进，领域知识由锤子研究；有效输入或明确委托充分时不重复确认。直接调用设计或Figma模块也不能绕过产品启动。

- [fusion-product-agent](skills/fusion-product-agent/SKILL.md)：产品主线，提供目标、领域依据、规则、范围与验收预期；接回设计结果，核对业务与版本。
- [fusion-design-core](skills/fusion-design-core/SKILL.md)：设计主责，负责设计研究、竞品、信息架构、流程/交互、风格、组件/素材、提示词与QA0终审。
- [fusion-design-ui-ux-pro-max](skills/fusion-design-ui-ux-pro-max/SKILL.md)：按设计任务检索UI/UX方法与实现建议。
- [fusion-figma-workflow](skills/fusion-figma-workflow/SKILL.md)：初始化与复用、工具/文件权限、生成/精修、真实画布证据、Dev Mode到Demo还原及文案/交互复核。
- [fusion-design-impeccable](skills/fusion-design-impeccable/SKILL.md)：按需制作、审视和精修；服务设计主流程，不另立产品规则或覆盖QA0。

旧设计判断方法已撤换；原有Figma配置、目标绑定、生成/精修、Dev Mode还原和专项复核由同包执行模块承接。产品能力模型保留原文，作为产品判断依据；它不与新设计模块争夺设计执行权。详见[替换范围与来源](SOURCE-MAP.md)。

## 当前工作链

每次成果、修订或提问的最终回复首行按[流程位置展示](skills/fusion-product-agent/references/progress-navigation.md)显示产品六阶段位置，设计中附设计四步骤位置及真实状态；结尾说明下一项产物、责任方或用户动作。导航不增加审批，位置从当前项目状态恢复。

想法与目标 → 产品目标/范围校准 → 领域需求、规则/边界/场景与方案 → [设计交接](skills/fusion-product-agent/references/design-and-demo.md) → 设计研究/交互推导 → [独立文案步骤](skills/fusion-product-agent/references/product-copy.md)与[界面文案基线](skills/fusion-product-agent/assets/interface-copy.md) → 专业设计制作与QA0 → 产品核对业务/版本 → PRD、验收与下游交接。

产品启动条件成立后，0到1设计按同事入口先完成并汇报研究、竞品、流程和具体交互，再原生提问确认风格等事项，随后调组件、主题、字体与真实素材制作；风格问答不能替代产品意图校准。存量延展和按正式稿还原走设计模块对应分流。不是所有任务都重新走0到1。

首次设计先按[执行工作流](skills/fusion-figma-workflow/SKILL.md)读取配置、询问未定路线并绑定用户目标。已有本产品Figma主稿或已选Figma时，先在Figma完成设计；旧页Computer Use精修，新增整页按需Figma Agent生成后精修，核验后由同版Dev Mode / MCP还原Demo。缺工具先恢复，不静默改走本地；明确选本地代码时沿用专业组件与素材。HTML转Figma仅为显式且实际可用的可选分支。

## 使用与完整安装

可在新的试验项目让Agent读取本包`skills/fusion-product-agent/SKILL.md`，按当前需求调用同包设计模块。无需把同事的整个JQ产品流程也装进来。

项目级Skill：

```sh
python3 scripts/install.py --project /absolute/path/to/project --mode skill --dry-run
python3 scripts/install.py --project /absolute/path/to/project --mode skill
```

五项Skill完整复制到项目`.agents/skills/`，新会话使用`$fusion-product-agent`。

项目级Subagent：

```sh
python3 scripts/install.py --project /absolute/path/to/project --mode agent --dry-run
python3 scripts/install.py --project /absolute/path/to/project --mode agent
```

五份完整资源复制到项目`.codex/resources/`，注册一个产品主Subagent。子Agent按相邻路径读取设计模块，不注册第二套项目Skill，也不自动启动额外Agent。主任务统一向用户提问。

两种安装方式互斥；任一同名资源已存在时拒绝整个安装，不覆盖本地定制；复制中途失败撤回本次资源。安装记录包含所有资源路径与摘要。既有项目配置保持原样，无配置时按原安装器规则写入最小Agent配置；不改全局设置。

包内插件元数据同时指向五项Skill和IconScout MCP声明。项目安装器仅复制规则/资源，不修改宿主MCP配置。首次安装后新会话加载；文件存在不代表运行已验证。

## 工具条件

自带方法、组件配方、主题/字体数据、真实素材处理和检查脚本，不提供Figma、Computer Use、浏览器、生图服务账号或付费素材权限。按[工具接入](skills/fusion-product-agent/references/figma-adapter.md)检查；已有有效配置复用，不乱建Figma文件。

安装/校验/交付引用辅助脚本使用Python 3.9+标准库；设计脚本依功能还可能依赖Node、Playwright、Pillow、网络或宿主工具，不应沿用旧包“所有脚本只需标准库”的描述。具体见各脚本帮助与实际环境。

## 检查与升级

```sh
python3 scripts/validate_package.py
python3 scripts/test_package.py
```

校验范围见[验证说明](VALIDATION.md)。安装清单`.codex/fusion-product-agent-install.json`包含`resources`及每份资源的摘要；卸载或升级要检查这些资源是否被本地修改，保留项目产物与定制，不整体删除`.agents`或`.codex`。旧版本仍用旧记录处理。

专业设计来源固定为同事分支`6dcc771`，见[设计来源清单](design-source.json)；原JQ 1.1.5的Figma执行层及本地适配见[Figma来源清单](figma-source.json)。明确适配了HTML优先、Figma Agent禁令和仅适合本地CSS的门槛，专业方法与QA0继续保留。脚本、组件和素材未删改。来源的既有许可与权利说明继续适用，本版不添加未经确认的统一开放许可。

文案编写、审查和实屏复核统一使用[界面文案质量标准](skills/fusion-product-agent/references/copy-quality.md)：四组标准与模型相关能力要求合并，文案基线记录适用性、依据和后续验证要求，不逐句重复全模型检查。

共用组件与规则按[共用基线方法](skills/fusion-product-agent/references/shared-components-and-rules.md)按需建立，优先引用已有规范；页面复用同一有效定义，允许有依据的变体，共享变更按使用位置核对。小需求可内联，不要求建设全套设计系统。

本轮涉及用户侧异常时，按[异常对应方法](skills/fusion-product-agent/references/exception-layers.md)实际产出[页面规则与文案对应](skills/fusion-product-agent/assets/exception-page-map.md)或沿用已有等价视图；准确文字只在文案基线维护，设计与实现引用同版关系。

## rc.10：异常呈现复用

rc.10按[呈现复用方法](skills/fusion-product-agent/references/exception-presentation-reuse.md)将异常覆盖与页面制作分开；不同业务状态可以复用呈现，独立页需有任务依据，状态展示Frame不自动变路由。

## rc.11：产品与技术执行分责

业务项目按[技术交接与分责](skills/fusion-product-agent/references/technical-handoff.md)区分约定本地前端制作和生产工程；Git写入/发布交技术Agent。安装为Skill或子Agent均使用同一边界，不自动安装/创建技术Agent或获得调用授权。
